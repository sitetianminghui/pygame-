import time, random
import sys
import pygame as pg 
from pygame.locals import *

pg.init()
coin = 100

font = pg.font.Font(None, 100)
coin_img = font.render("coin:"+str(coin), True, (200, 100, 0))
class Timer:
    def __init__(self, millis):
        self.millis = millis
        self.running = False
    def start(self):
        self.running = True
        self.start_time = time.time()
    def run(self, func):
        if(self.running):
            if((time.time() - self.start_time)*1000 >= self.millis):
                func()
                self.start_time = time.time()
                
    def stop(self):
        self.running = False
        

class Zombie(pg.sprite.Sprite):
    images = {}
    images['attack'] = [pg.image.load("assets/Zombie/ZombieAck/%s_%d.png" % ('ZombieAttack', i)) 
                      for i in range(21)]
    images['walk'] = [pg.image.load("assets/Zombie/ZombieMove/%s_%d.png" % ('Zombie', i)) 
                      for i in range(22)]
    
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.run = True
        self.speed = .5
        self.mpf = 5    # move per frame
        self.x = 1200
        self.y = 0
        self.max_hp = 100
        self.hp = self.max_hp
        self.hp_width = self.hp/self.max_hp * 100    # 90//100
        self.next_frame_timer = 0
        self.animation = "walk"
        self.frames = len(Zombie.images[self.animation])
        self.frame = 0
        width = Zombie.images[self.animation][0].get_width()
        height = Zombie.images[self.animation][0].get_height()
        self.width = width
        self.height = height
        self.rect = pg.Rect(self.x, self.y-height*.5, self.width, self.height)
        self.hp_sep = 100 // (self.max_hp // 50)
    
    def switchto(self, animation):
        self.animation = animation
        if animation == 'walk': 
            self. frames = len(Zombie.images[self.animation]); self.frame=0
        elif animation == 'attack':
            self.frames = len(Zombie.images[self.animation]); self.frame=0
        self.run = True if animation == 'walk' else False
    
    def draw_hp(self):
        pg.draw.rect(Game.window, (0,0,0), (self.x-40, self.y-70, 110, 18))
        pg.draw.rect(Game.window, (0,200,0), (self.x-35, self.y-65, self.hp_width, 8))
        pg.draw.rect(Game.window, (200,0,0), (self.x-35+self.hp_width, self.y-65, 100-self.hp_width, 10))
        for i in range(self.hp_sep, int(self.hp/self.max_hp * 100), self.hp_sep):
            pg.draw.line(Game.window, (0,0,0), (self.x-35+i, self.y-65), (self.x-35+i, self.y-59), 1)
        
    def hurt(self):
        global coin, coin_img
        self.hp -= 10
        self.hp_width = self.hp/self.max_hp * 100    # 90//100
    
    def attack(self):
        pass
    
    def next_frame(self):
        if self.run:
            self.x -= self.speed
        self.rect = pg.Rect(self.x, self.y-self.height*.5, 50, self.height)
        self.next_frame_timer += 1
        self.draw_hp()        
        if self.next_frame_timer >= self.mpf:
            self.next_frame_timer = 0
            self.frame+=1
            if self.frame>=self.frames:
                self.frame = 0
                
    def update(self):
        
        # pg.draw.rect(Game.window, (255,0,0), self.rect)
        Game.window.blit(Zombie.images[self.animation][self.frame], (self.x-self.width//2, self.y-self.height//2))
        self.next_frame()

class ConeheadZombie(Zombie):
    images = {}
    images['attack'] = [pg.image.load("assets/Zombie/ZombieAck/%s_%d.png" % ('ConeheadZombieAttack', i)) 
                      for i in range(11)]
    images['walk'] = [pg.image.load("assets/Zombie/ZombieMove/%s_%d.png" % ('ConeheadZombie', i)) 
                      for i in range(21)]
    def __init__(self):
        Zombie.__init__(self)
        self.max_hp = 200
        self.speed = .4
        self.mpf = 6
        self.hp = self.max_hp
        self.hp_sep = 100 // (self.max_hp//50)
        self.frames = len(ConeheadZombie.images['walk'])
    
    def switchto(self, animation):
        self.animation = animation
        if animation == 'walk': 
            self. frames = len(ConeheadZombie.images[self.animation]); self.frame=0
        elif animation == 'attack':
            self.frames = len(ConeheadZombie.images[self.animation]); self.frame=0
        self.run = True if animation == 'walk' else False
    
    def update(self):
        self.next_frame()
        # pg.draw.rect(Game.window, (255,0,0), self.rect)
        Game.window.blit(ConeheadZombie.images[self.animation][self.frame], (self.x-self.width//2, self.y-self.height//2))
        
class FlagZombie(Zombie):
    images = {}
    images['attack'] = [pg.image.load("assets/Zombie/ZombieAck/%s_%d.png" % ('FlagZombieAttack', i)) 
                      for i in range(11)]
    images['walk'] = [pg.image.load("assets/Zombie/ZombieMove/%s_%d.png" % ('FlagZombie', i)) 
                      for i in range(12)]
    def __init__(self):
        Zombie.__init__(self)
        self.max_hp = 300
        self.speed = .8
        self.mpf = 6
        self.hp = self.max_hp
        self.hp_sep = 100 // (self.max_hp // 50)
        self.frames = len(FlagZombie.images['walk'])
    
    def switchto(self, animation):
        self.animation = animation
        if animation == 'walk': 
            self. frames = len(FlagZombie.images[self.animation]); self.frame=0
        elif animation == 'attack':
            self.frames = len(FlagZombie.images[self.animation]); self.frame=0
        self.run = True if animation == 'walk' else False
    
    def update(self):
        self.next_frame()
        # pg.draw.rect(Game.window, (255,0,0), self.rect)
        Game.window.blit(FlagZombie.images[self.animation][self.frame], (self.x-self.width//2, self.y-self.height//2))

class BucketheadZombie(Zombie):
    images = {}
    images['attack'] = [pg.image.load("assets/Zombie/ZombieAck/%s_%d.png" % ('BucketheadZombieAttack', i)) 
                      for i in range(11)]
    images['walk'] = [pg.image.load("assets/Zombie/ZombieMove/%s_%d.png" % ('BucketheadZombie', i)) 
                      for i in range(15)]
    def __init__(self):
        Zombie.__init__(self)
        self.speed = .2
        self.mpf = 15
        self.max_hp = 500
        self.hp = self.max_hp
        self.hp_sep = 100 // (self.max_hp // 50)
        self.frames = len(BucketheadZombie.images['walk'])
    
    def switchto(self, animation):
        self.animation = animation
        if animation == 'walk': 
            self. frames = len(BucketheadZombie.images[self.animation]); self.frame=0
        elif animation == 'attack':
            self.frames = len(BucketheadZombie.images[self.animation]); self.frame=0
        self.run = True if animation == 'walk' else False
    
    def update(self):
        self.next_frame()
        # pg.draw.rect(Game.window, (255,0,0), self.rect)
        Game.window.blit(BucketheadZombie.images[self.animation][self.frame], (self.x-self.width//2, self.y-self.height//2))

class Plant(pg.sprite.Sprite):
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.x = 100
        self.y = 300
        self.max_hp = 100
        self.hp = self.max_hp 
        self.hp_width = self.hp / self.max_hp * 100
        
    def shoot(self):
        pass 
    
    def update(self):
        pass 
    
class PeaShooter(Plant):
    imgs = [pg.image.load(f"assets/plants/Peashooter_{i:02d}.png") for i in range(13)]
    frames = len(imgs)
    def __init__(self,position):
        Plant.__init__(self)
        self.x = position[0]
        self.y = position[1]
        self.next_frame_timer = 0
        self.frame = 0
        self.attacked = 0
        self.height = 70
        self.width = 70
        self.rect = pg.Rect(self.x, self.y, 20, 20)
        self.shoot_position = [self.x+30, self.y-10]
        self.rect = pg.Rect(self.x-20, self.y-self.height*.5, 40, self.height)
        self.timer = Timer(1000)    # 100ms
    
    def draw_hp(self):
        pg.draw.rect(Game.window, (100,100,100), (self.x-40, self.y-50, 110, 20))
        pg.draw.rect(Game.window, (0,200,0), (self.x-35, self.y-45, self.hp_width, 10))      
        
    def update(self):
        self.next_frame_timer += 1
        # pg.draw.circle(Game.window, (0,0,200), self.shoot_position, 10)
        # pg.draw.rect(Game.window, (255,0,0), self.rect)
        if self.attacked:
            self.draw_hp()
            
        Game.window.blit(PeaShooter.imgs[self.frame], (self.x-self.width//2, self.y-self.height//2))
        if self.next_frame_timer >= 5:
            self.next_frame_timer = 0
            self.frame+=1
            if self.frame>=PeaShooter.frames:
                self.frame = 0
            # if attacked
            if self.attacked:
                self.hp -= 1
                self.hp_width = self.hp / self.max_hp * 100
                
            # fire, add a bullet to Game.bullet while timer countdown
            self.timer.run(self.shoot)
            
    def shoot(self):
        b = Bullet(self.shoot_position[0]-35, self.shoot_position[1]-25)
        Game.bullets.add(b)

class Bullet(pg.sprite.Sprite):
    img = pg.image.load("assets/plants/Bullet_1.png")
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.rect = pg.Rect(self.x+30, self.y+8, 20, 20)
    
    def update(self):
        self.x += 10
        self.rect = pg.Rect(self.x+30, self.y+8, 20, 20)
        # pg.draw.rect(Game.window, (0,200,0), self.rect)
        Game.window.blit(Bullet.img, (self.x, self.y))
        

class Game:
    width = 1280
    height = 720
    gameover = 0
    fps = 60
    window = pg.display.set_mode((width, height))
    clock = pg.time.Clock()
    zombie_generate_timer = Timer(1000)
    bullets = pg.sprite.Group()
    zombies = [pg.sprite.Group() for i in range(3)]
    plants = [pg.sprite.Group() for i in range(3)]
    place_plant_x = [130+112*i for i in range(10)]
    place_plant_y = (223, 370, 522)
    m = "    z        zzz  c  f     zzcfcfbzzc              b  b b  czz  b fc b b z b ff f b z b  b"
    map_index = -1
    
    def __init__(self, name):
        self.plant_placed = [[0 for i in range(10)] for j in range(3)]
        Game.zombie_generate_timer.start()
        self.bac = [pg.image.load("assets/scene/%s/%s.png" %(name, 'left')),
               pg.image.load("assets/scene/%s/%s.png" %(name, 'mid')),
               pg.image.load("assets/scene/%s/%s.png" %(name, 'right'))]
        self.bac_width = (500, 1280, 702)
    
    def _input(self, event):
        global coin, coin_img
        if event.type == pg.QUIT:
            Game.gameover = 1
        if event.type == pg.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pg.mouse.get_pos()
            if coin >= 20:
                for xi in range(10):
                    for yi in range(3):
                        x = Game.place_plant_x[xi]
                        y = Game.place_plant_y[yi]
                        if x-50 < mouse_x < x+50 and y-50 < mouse_y < y+50 and not self.plant_placed[yi][xi]:
                            p = PeaShooter((x, y))
                            p.xi = xi
                            p.yi = yi
                            Game.plants[yi].add(p)
                            coin -= 20
                            coin_img = font.render("coin:"+str(coin), True, (200,100,0))
                            self.plant_placed[yi][xi] = 1
            
    def logic_per2f(self):
        global coin, coin_img
        # generate zombie while the timer countdown
        Game.zombie_generate_timer.run(self.add_zombie)        
        # del the bullet and decrease zombie hp while they collided
        for i in range(3):
            zombie = Game.zombies[i]
            a = pg.sprite.groupcollide(zombie, Game.bullets, dokilla=False, dokillb=True)
            if a:
                # zombie attacked, decreace zombie hp
                z = list(a.keys())[0]
                z.hurt()
                if z.hp<=0:
                    coin += z.max_hp//100* 10
                    coin_img = font.render("coin:"+str(coin), True, (200,100,0))       
                    z.kill()
                    #  switch plant animation rowly (shoot or not) while zombie die correspondingly
                    zombie = Game.zombies[i]
                    if not zombie:
                        for p in Game.plants[i]:
                            if p.timer.running:
                                p.timer.stop()   
        
    def logic_per20f(self):
        # switch zombie animation 
        for i in range(3):
            zombies_len = len(Game.zombies[i])
            plants_len = len(Game.plants[i])
            zombies = Game.zombies[i].sprites()
            plants = Game.plants[i].sprites()
            # check every zombie to determine whether it is collided with the plant
            for j in range(zombies_len):
                collided = 0
                for k in range(plants_len):
                    if -20<=zombies[j].x - plants[k].x<20:
                        collided = 1
                        break 
                # if not collided
                if not collided:
                    if zombies[j].animation == 'attack':
                        zombies[j].switchto('walk')
                        
                # collided
                elif zombies[j].animation == 'walk':
                    zombies[j].switchto('attack')
                    
            for j in range(plants_len):
                collided = 0
                for k in range(zombies_len):
                    if -20<=plants[j].x-zombies[k].x<20:
                        collided = 1
                        break
                # if not 
                if collided:
                    plants[j].attacked = 1
                    if plants[j].hp<=0:
                        self.plant_placed[plants[j].yi][plants[j].xi] = 0
                        plants[j].kill()
                else:
                    plants[j].attacked = 0
                    
    def logic_per150f(self):
        #  switch plant animation rowly (shoot or not) while zombie die correspondingly
        for i in range(3):
            if Game.zombies[i]:
                for p in Game.plants[i]:
                    if not p.timer.running:
                        p.timer.start() 
        # del the item when run out of screen
        for zombies in Game.zombies:
            for i in zombies.sprites():
                if i.x < -500:
                    i.kill()
                    del i        
        for b in Game.bullets.sprites():
            if b.x > 600:
                b.kill()
                del b
    
    def add_zombie(self):
        Game.map_index += 1
        if Game.map_index >= len(Game.m):
            Game.map_index = -1     
        if Game.m[Game.map_index] == 'z':   pz = Zombie()
        elif Game.m[Game.map_index] == 'c': pz = ConeheadZombie()
        elif Game.m[Game.map_index] == 'f': pz = FlagZombie()
        elif Game.m[Game.map_index] == 'b': pz = BucketheadZombie()
        else:   return 
        
        # Zombie, ConeheadZombie, FlagheadZombie, BucketheadZombie
        rt = random.randint(0,2)
        pz.y = Game.place_plant_y[rt]
        Game.zombies[rt].add(pz)
        #  switch plant animation rowly (shoot or not) while zombie die correspondingly
        for p in Game.plants[rt]:
            if not p.timer.running:
                p.timer.start()
    
    def update(self):
        Game.window.fill((0,0,0))
        Game.window.blit(self.bac[1], (0,0))
        for plants in Game.plants:   plants.update()
        for zombies in Game.zombies: zombies.update()
        Game.bullets.update()
        Game.window.blit(coin_img, (30,10))
    
    def slide_show(self):
        x = self.bac_width[0]
        running = 1
        sudu = -2
        while running:
            x += sudu
            if x<=-self.bac_width[2]:
                sudu = -sudu
            if sudu == 2 and x>=0:
                x = 0
                running = 0
            Game.clock.tick(60)
            Game.window.blit(self.bac[0], (x-self.bac_width[0], 0))
            Game.window.blit(self.bac[1], (x,0))
            Game.window.blit(self.bac[2], (x+self.bac_width[1], 0))
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
            pg.display.update()
            
    def start_game(self):
        # self.slide_show()
        frame = 0
        while not Game.gameover:
            frame += 1
            Game.clock.tick(Game.fps)
            for event in pg.event.get():
                self._input(event)
            if frame%2==0:
                self.logic_per2f()
            if frame%20==0:
                self.logic_per20f()
            if frame%150==0:
                self.logic_per150f()
            self.update()
            pg.display.update()
        pg.quit()
        sys.exit()
            
if __name__ == '__main__':
    game = Game('egypt')
    game.start_game()
